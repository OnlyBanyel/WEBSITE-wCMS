// Ensure this code runs only once
let initComplete = false;

$(document).ready(function () {
  // Your existing page loading code
  var savedPage = localStorage.getItem("activePage");

  // Only try to load the saved page if it exists
  if (savedPage) {
    loadPage(savedPage);
  }

  // Add a flag to prevent multiple initializations
  if (!initComplete) {
    initComplete = true;
    initFormHandlers();
    // Initialize SHS handlers only if we're on the SHS page
    if (window.location.pathname.includes("shs.php")) {
      initSHSHandlers();
    }
  }

  // Modified loadPage function
  function loadPage(file) {
    $(".dynamic-load").removeClass("active");
    $(".dynamic-load[data-file='" + file + "']").addClass("active");

    $.ajax({
      url: file,
      type: "GET",
      success: function (response) {
        // Remove any script tags from the response to prevent multiple initializations
        var filteredResponse = response.replace(
          /<script\b[^>]*>([\s\S]*?)<\/script\b>/gi,
          ""
        );

        // Update the main content
        $("#main-content-section").html(filteredResponse);

        // Reinitialize necessary components
        if ($("#main-content-section #carouselExampleSlidesOnly").length > 0) {
          $("#carouselExampleSlidesOnly").carousel();
        }

        // Reinitialize form handlers
        initFormHandlers();

        // Only initialize SHS handlers if we're on the SHS page
        if (file.includes("shs.php") && !initComplete) {
          window.initComplete = true; // Prevent re-initialization
          initSHSHandlers();
        }
      },
      error: function () {
        $("#main-content-section").html(
          "<p style='color:red;'>Failed to load content.</p>"
        );
      },
    });
  }

  // Initialize form handlers with proper cleanup
  function initFormHandlers() {
    // Off any existing handlers before attaching new ones
    $(document).off("submit", "form.status-form");

    $(document).on("submit", "form.status-form", function (e) {
      e.preventDefault();
      var form = $(this);
      var isSuspend = form.find('[name="suspend_account"]').length > 0;
      var managerId = form.find('[name="manager_id"]').val();

      if (!managerId) {
        alert("Error: Invalid account ID");
        return false;
      }

      // Confirm before taking action
      if (
        isSuspend &&
        !confirm("Are you sure you want to suspend this account?")
      ) {
        return false;
      }

      if (
        !isSuspend &&
        !confirm("Are you sure you want to reactivate this account?")
      ) {
        return false;
      }

      // Create FormData object and process the form
      var formData = new FormData(form[0]);
      console.log("Submitting form with manager_id:", managerId);
      console.log("Action:", isSuspend ? "suspend" : "reactivate");

      // Show loading indicator
      const button = form.find('button[type="submit"]');
      const originalButtonText = button.html();
      button.html("Processing...").prop("disabled", true);

      $.ajax({
        url: "../page-functions/update-account-status.php",
        type: "POST",
        data: formData,
        processData: false,
        contentType: false,
        dataType: "json",
        headers: {
          "X-Requested-With": "XMLHttpRequest",
        },
        success: function (response) {
          button.html(originalButtonText).prop("disabled", false);
          console.log("Server Response:", response);
          if (response.success) {
            var card = form.closest(".bg-white");
            var statusBadge = card.find(".inline-flex.items-center");

            if (response.newStatus === 0) {
              statusBadge
                .removeClass("bg-green-100 text-green-800")
                .addClass("bg-red-100 text-red-800").html(`
                                <svg xmlns="http://www.w3.org/2000/svg" class="h-3 w-3 mr-1" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                                  <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 8v4m0 4h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z" />
                                </svg>
                                Suspended
                              `);

              form.html(`
                            <input type="hidden" name="manager_id" value="${managerId}">
                            <input type="hidden" name="reactivate_account" value="1">
                            <button type="submit" class="inline-flex items-center px-4 py-2 bg-green-600 text-white text-sm font-medium rounded-md hover:bg-green-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-green-500 transition">
                              <svg xmlns="http://www.w3.org/2000/svg" class="h-4 w-4 mr-1" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z" />
                              </svg>
                              Reactivate Account
                            </button>
                          `);
            } else {
              statusBadge
                .removeClass("bg-red-100 text-red-800")
                .addClass("bg-green-100 text-green-800").html(`
                                <svg xmlns="http://www.w3.org/2000/svg" class="h-3 w-3 mr-1" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                                  <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M5 13l4 4L19 7M18.364 18.364A9 9 0 005.636 5.636m12.728 12.728A9 9 0 015.636 5.636m12.728 12.728L5.636 5.636" />
                                </svg>
                                Active
                              `);

              form.html(`
                            <input type="hidden" name="manager_id" value="${managerId}">
                            <input type="hidden" name="suspend_account" value="1">
                            <button type="submit" class="inline-flex items-center px-4 py-2 bg-red-600 text-white text-sm font-medium rounded-md hover:bg-red-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-red-500 transition">
                              <svg xmlns="http://www.w3.org/2000/svg" class="h-4 w-4 mr-1" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M18.364 18.364A9 9 0 005.636 5.636M12 8l-3.096 3.096a4 4 0 00-5.656 0M12 8l3.096 3.096a4 4 0 005.656 0M16 13.532l-3.096 3.096a4 4 0 01-5.656 0M16 13.532l2.763 2.763a4 4 0 005.656 0M16 13.532l-5.657 5.657a4 4 0 01-5.656 0M12 8l5.657 5.657a4 4 0 015.657 0M12 8l-3.096 3.096a4 4 0 00-5.656 0M12 8l3.096-3.096a4 4 0 015.656 0M12 8l-3.096 3.096a4 4 0 005.656 0M12 8l3.096-3.096a4 4 0 015.657 0M12 8l-3.096 3.096a4 4 0 00-5.656 0M12 8l3.096-3.096a4 4 0 015.656 0" />
                              </svg>
                              Suspend Account
                            </button>
                          `);
            }

            // Show success message
            alert(response.message);
          } else {
            alert(
              "Error: " +
                (response.message || "Failed to update account status")
            );
          }
        },
        error: function (xhr, status, error) {
          button.html(originalButtonText).prop("disabled", false);
          console.error("AJAX Error:", status, error);
          console.log("Response Text:", xhr.responseText);

          if (
            xhr.responseText &&
            xhr.responseText.indexOf("<!DOCTYPE html>") !== -1
          ) {
            if (xhr.responseText.indexOf("login-form.php") !== -1) {
              alert(
                "Your session has expired. Please refresh the page and log in again."
              );
            } else {
              alert(
                "Server error: The request could not be processed. Please refresh the page and try again."
              );
            }
          } else {
            try {
              var responseObj = JSON.parse(xhr.responseText);
              alert(
                "Error: " +
                  (responseObj.message || "Failed to update account status")
              );
            } catch (e) {
              alert(
                "An error occurred while updating the account status: " + error
              );
            }
          }
        },
      });
    });

    initSHSHandlers();
  }

  // SHS Page Functionality
  function initSHSHandlers() {
    console.log("Initializing SHS handlers");

    // Toggle strand details and update SHS content via AJAX
    $(document).on("click", ".strand-toggle", function () {
      const strandId = $(this).data("strand-id");
      const strandDetails = $("#" + strandId + "-details");

      if (strandDetails.length) {
        strandDetails.toggleClass("hidden");

        // Toggle icon
        const icon = $(this).find("i");
        if (icon.length) {
          if (strandDetails.hasClass("hidden")) {
            icon.removeClass("fa-chevron-up").addClass("fa-chevron-down");
          } else {
            icon.removeClass("fa-chevron-down").addClass("fa-chevron-up");
          }
        }
      }
    });

    // Add new subject to strand
    $(document).on("click", ".add-subject-btn", function () {
      const strandId = $(this).data("strand-id");
      const subjectsList = $("#" + strandId + "-subjects-list");
      const subjectCount = subjectsList.find(".subject-item").length + 1;

      // Create new subject item
      const newSubjectItem = $("<div>")
        .addClass("subject-item mb-2 flex items-center")
        .append(
          $("<input>").attr({
            type: "text",
            class: "form-control w-full p-2 border rounded",
            name: "new-subject-" + strandId + "-" + subjectCount,
            placeholder: "Enter subject name",
          })
        )
        .append(
          $("<button>")
            .addClass(
              "save-subject-btn ml-2 bg-green-500 text-white p-2 rounded"
            )
            .attr("data-strand-id", strandId)
            .attr("data-index", subjectCount)
            .append($("<i>").addClass("fas fa-save"))
        )
        .append(
          $("<button>")
            .addClass(
              "remove-subject-btn ml-2 bg-red-500 text-white p-2 rounded"
            )
            .append($("<i>").addClass("fas fa-trash"))
        );

      if (subjectsList.length) {
        subjectsList.append(newSubjectItem);
      }
    });

    // Save new subject
    $(document).on("click", ".save-subject-btn", function () {
      const strandId = $(this).data("strand-id");
      const index = $(this).data("index");
      const inputField = $(this).parent().find("input");
      const content = inputField.val().trim();

      if (!content) {
        alert("Please enter a subject name");
        return;
      }

      // Prepare form data
      const formData = new FormData();
      formData.append("type", "subject");
      formData.append("isNew", "true");
      formData.append("subpage", "31"); // SHS subpage
      formData.append("content", content);
      formData.append("index", index);
      formData.append("strandID", strandId);

      $.ajax({
        url: "../page-functions/addStrandItem.php",
        type: "POST",
        data: formData,
        contentType: false,
        processData: false,
        dataType: "json",
        success: function (response) {
          if (response.success) {
            // Update the UI
            const subjectItem = $(this).parent();
            subjectItem.html(`
                          <input type="text" 
                                 class="form-control w-full p-2 border rounded" 
                                 name="subject-${response.outcomeID}" 
                                 value="${content}">
                          <button type="button" class="update-subject-btn ml-2 bg-blue-500 text-white p-2 rounded" 
                                  data-outcome-id="${response.outcomeID}">
                              <i class="fas fa-save"></i>
                          </button>
                          <button type="button" class="delete-subject-btn ml-2 bg-red-500 text-white p-2 rounded" 
                                  data-outcome-id="${response.outcomeID}">
                              <i class="fas fa-trash"></i>
                          </button>
                      `);

            alert(response.message);
          } else {
            alert("Error: " + response.message);
          }
        },
        error: function (xhr, status, error) {
          console.error("AJAX Error:", status, error);
          alert("An error occurred while saving the subject");
        },
      });
    });

    // Update existing subject
    $(document).on("click", ".update-subject-btn", function () {
      const outcomeId = $(this).data("outcome-id");
      const inputField = $(this).parent().find("input");
      const content = inputField.val().trim();

      if (!content) {
        alert("Please enter a subject name");
        return;
      }

      // Prepare form data
      const formData = new FormData();
      formData.append("type", "subject");
      formData.append("isNew", "false");
      formData.append("subpage", "31"); // SHS subpage
      formData.append("outcomeID", outcomeId);
      formData.append("content", content);

      $.ajax({
        url: "../page-functions/updateStrandItem.php",
        type: "POST",
        data: formData,
        contentType: false,
        processData: false,
        dataType: "json",
        success: function (response) {
          if (response.success) {
            alert(response.message);
          } else {
            alert("Error: " + response.message);
          }
        },
        error: function (xhr, status, error) {
          console.error("AJAX Error:", status, error);
          alert("An error occurred while updating the subject");
        },
      });
    });

    // Delete subject
    $(document).on("click", ".delete-subject-btn", function () {
      const outcomeId = $(this).data("outcome-id");

      if (confirm("Are you sure you want to delete this subject?")) {
        const formData = new FormData();
        formData.append("outcomeID", outcomeId);

        $.ajax({
          url: "../page-functions/deleteStrandOutcome.php",
          type: "POST",
          data: formData,
          contentType: false,
          processData: false,
          dataType: "json",
          success: function (response) {
            if (response.success) {
              // Remove the subject item from the UI
              $(this).parent().remove();
              alert(response.message);
            } else {
              alert("Error: " + response.message);
            }
          },
          error: function (xhr, status, error) {
            console.error("AJAX Error:", status, error);
            alert("An error occurred while deleting the subject");
          },
        });
      }
    });

    // Remove new subject (not yet saved)
    $(document).on("click", ".remove-subject-btn", function () {
      if (confirm("Are you sure you want to remove this subject?")) {
        $(this).parent().remove();
      }
    });

    // Add/remove sections functionality
    $(document).on("click", "button.add-modal", function (e) {
      e.preventDefault();
      var sectionName = $(this).data("section");
      var allowedElements = $(this).data("allowed-elements");
      if (typeof allowedElements === "string") {
        allowedElements = JSON.parse(allowedElements);
      }

      $.ajax({
        url: "../modals/add_modal.php",
        type: "POST",
        data: {
          section: sectionName,
          allowedElements: JSON.stringify(allowedElements),
        },
        success: function (response) {
          $("#modalContent").html(response);
          $("#addModal").modal("show");
        },
        error: function () {
          alert("Error loading first modal.");
        },
      });
    });

    // Handle removing elements
    $(document).on("click", ".remove-element", function () {
      if (confirm("Are you sure you want to delete this element?")) {
        const elementID = $(this).data("element-id");
        const form = $(this).closest("form");

        $.ajax({
          url: "../page-functions/removeElement.php",
          type: "POST",
          data: {
            elementID: elementID,
          },
          success: function (response) {
            if (response.success) {
              $(form.find(".element-container-" + elementID)).remove();
              alert(response.message);
            } else {
              alert("Error: " + response.message);
            }
          },
          error: function () {
            alert("Error removing element");
          },
        });
      }
    });

    // Handle profile picture upload
    $(document).on("submit", "#profilePictureForm", function (e) {
      e.preventDefault();

      const formData = new FormData(this);
      formData.append("formType", "profilePicture");

      const button = $(this).find("button[type='submit']");
      const originalText = button.text();
      button.text("Processing...").prop("disabled", true);

      $.ajax({
        url: "../page-functions/updateAccount.php",
        type: "POST",
        data: formData,
        contentType: false,
        processData: false,
        dataType: "json",
        success: function (response) {
          button.text(originalText).prop("disabled", false);
          if (response.success) {
            alert(response.message);
            // Update the profile picture preview
            if (response.newPath) {
              $("#profilePreview").attr("src", response.newPath);
            }
          } else {
            alert("Error: " + response.message);
          }
        },
        error: function (xhr, status, error) {
          button.text(originalText).prop("disabled", false);
          console.error("AJAX Error:", status, error);
          alert("An error occurred while updating your profile picture.");
        },
      });
    });
  }
});

// Personal Information Form
$(document).on("submit", "#personalInfoForm", function (e) {
  e.preventDefault();

  var formData = new FormData(this);
  formData.append("formType", "personalInfo");

  $.ajax({
    url: "../page-functions/updateAccount.php",
    type: "POST",
    data: formData,
    contentType: false,
    processData: false,
    dataType: "json",
    success: (response) => {
      if (response.success) {
        alert(response.message);
      } else {
        alert("Error: " + response.message);
      }
    },
    error: (xhr, status, error) => {
      console.error("AJAX Error:", status, error, xhr.responseText);
      alert("An error occurred while updating your personal information.");
    },
  });
});

// Email Form
$(document).on("submit", "#emailForm", function (e) {
  e.preventDefault();

  var formData = new FormData(this);
  formData.append("formType", "email");

  $.ajax({
    url: "../page-functions/updateAccount.php",
    type: "POST",
    data: formData,
    contentType: false,
    processData: false,
    dataType: "json",
    success: (response) => {
      if (response.success) {
        alert(response.message);
      } else {
        alert("Error: " + response.message);
      }
    },
    error: (xhr, status, error) => {
      console.error("AJAX Error:", status, error, xhr.responseText);
      alert("An error occurred while updating your email.");
    },
  });
});

// Password Form
$(document).on("submit", "#passwordForm", function (e) {
  e.preventDefault();

  var formData = new FormData(this);
  formData.append("formType", "password");

  $.ajax({
    url: "../page-functions/updateAccount.php",
    type: "POST",
    data: formData,
    contentType: false,
    processData: false,
    dataType: "json",
    success: (response) => {
      if (response.success) {
        alert(response.message);
        // Clear password fields on success
        $("#currentPassword, #newPassword, #confirmPassword").val("");
      } else {
        alert("Error: " + response.message);
      }
    },
    error: (xhr, status, error) => {
      console.error("AJAX Error:", status, error, xhr.responseText);
      alert("An error occurred while updating your password.");
    },
  });
});

// Add this code after the existing event handlers for adding new departments and courses

// Handle "Add New Department" button click with AJAX
$(document).on("click", "#addNewDepartment", function (e) {
  e.preventDefault();

  // Show loading indicator
  $(this).html(
    '<div class="spinner-border spinner-border-sm text-light" role="status"><span class="visually-hidden">Loading...</span></div> Adding...'
  );
  $(this).prop("disabled", true);

  var currentPage = $(".dynamic-load.active").data("file");

  $.ajax({
    url: "../page-functions/addDepartment.php",
    type: "POST",
    data: { addNewDepartment: 1 },
    dataType: "json",
    success: (response) => {
      if (response.success) {
        alert(response.message);
        // Load the departments page without full page reload
        if (currentPage) {
          loadPage(currentPage);
        } else if (response.redirect) {
          loadPage(response.redirect);
        }
      } else {
        alert("Error: " + response.message);
        // Reset button
        $("#addNewDepartment").html(
          '<svg xmlns="http://www.w3.org/2000/svg" class="h-12 w-12 mb-2" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 6v6m0 0v6m0-6h6m-6 0H6" /></svg><span class="font-medium">Add New Department</span>'
        );
        $("#addNewDepartment").prop("disabled", false);
      }
    },
    error: () => {
      alert("An error occurred. Please try again.");
      // Reset button
      $("#addNewDepartment").html(
        '<svg xmlns="http://www.w3.org/2000/svg" class="h-12 w-12 mb-2" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 6v6m0 0v6m0-6h6m-6 0H6" /></svg><span class="font-medium">Add New Department</span>'
      );
      $("#addNewDepartment").prop("disabled", false);
    },
  });
});

// Handle "Add New Course" buttons with AJAX
$(document).on(
  "click",
  "#addNewUndergradCourse, #addNewGradCourse",
  function (e) {
    e.preventDefault();

    // Show loading indicator
    $(this).html(
      '<div class="spinner-border spinner-border-sm text-light" role="status"><span class="visually-hidden">Loading...</span></div> Adding...'
    );
    $(this).prop("disabled", true);

    var courseType =
      $(this).attr("id") === "addNewUndergradCourse" ? "undergrad" : "grad";
    var currentPage = $(".dynamic-load.active").data("file");

    $.ajax({
      url: "../page-functions/addCourse.php",
      type: "POST",
      data: { courseType: courseType },
      dataType: "json",
      success: (response) => {
        if (response.success) {
          alert(response.message);
          // Load the courses page without full page reload
          if (currentPage) {
            loadPage(currentPage);
          } else if (response.redirect) {
            loadPage(response.redirect);
          }
        } else {
          alert("Error: " + response.message);
          // Reset button
          var buttonHtml =
            '<svg xmlns="http://www.w3.org/2000/svg" class="h-12 w-12 mb-2" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 6v6m0 0v6m0-6h6m-6 0H6" /></svg><span class="font-medium">Add New ' +
            (courseType === "undergrad" ? "Undergraduate" : "Graduate") +
            " Course</span>";
          $(e.target).html(buttonHtml);
          $(e.target).prop("disabled", false);
        }
      },
      error: () => {
        alert("An error occurred. Please try again.");
        // Reset button
        var buttonHtml =
          '<svg xmlns="http://www.w3.org/2000/svg" class="h-12 w-12 mb-2" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 6v6m0 0v6m0-6h6m-6 0H6" /></svg><span class="font-medium">Add New ' +
          (courseType === "undergrad" ? "Undergraduate" : "Graduate") +
          " Course</span>";
        $(e.target).html(buttonHtml);
        $(e.target).prop("disabled", false);
      },
    });
  }
);

// SHS Page Functionality
function initSHSHandlers() {
  console.log("Initializing SHS handlers");

  // Toggle strand details
  $(document).on("click", ".strand-toggle", function () {
    const strandId = $(this).data("strand-id");
    const strandDetails = $("#strand-details-" + strandId);

    if (strandDetails.length) {
      strandDetails.toggleClass("hidden");

      // Toggle icon
      const icon = $(this).find("i");
      if (icon.length) {
        if (strandDetails.hasClass("hidden")) {
          icon.removeClass("fa-chevron-up").addClass("fa-chevron-down");
        } else {
          icon.removeClass("fa-chevron-down").addClass("fa-chevron-up");
        }
      }
    }
  });

  // Add new subject to strand
  $(document).on("click", ".add-subject-btn", function () {
    const strandId = $(this).data("strand-id");
    const subjectsList = $("#subjects-list-" + strandId);
    const subjectCount = subjectsList.find(".subject-item").length + 1;

    // Create new subject item
    const newSubjectItem = $(`
        <div class="subject-item mb-2 flex items-center">
          <input type="text" class="form-control w-full p-2 border rounded" 
                 name="new-subject-${strandId}-${subjectCount}" 
                 placeholder="Enter subject name">
          <button type="button" class="save-subject-btn ml-2 bg-green-500 text-white p-2 rounded" 
                  data-strand-id="${strandId}" 
                  data-index="${subjectCount}">
              <i class="fas fa-save"></i>
          </button>
          <button type="button" class="remove-subject-btn ml-2 bg-red-500 text-white p-2 rounded">
              <i class="fas fa-trash"></i>
          </button>
        </div>
      `);

    subjectsList.append(newSubjectItem);
  });

  // Save new subject
  $(document).on("click", ".save-subject-btn", function () {
    const strandId = $(this).data("strand-id");
    const index = $(this).data("index");
    const inputField = $(this).parent().find("input");
    const content = inputField.val().trim();

    if (!content) {
      alert("Please enter a subject name");
      return;
    }

    // Send AJAX request to save the new subject
    const formData = new FormData();
    formData.append("type", "subject");
    formData.append("isNew", "true");
    formData.append("subpage", "31"); // SHS subpage
    formData.append("content", content);
    formData.append("index", index);
    formData.append("strandID", strandId);

    $.ajax({
      url: "../page-functions/addStrandItem.php",
      type: "POST",
      data: formData,
      contentType: false,
      processData: false,
      dataType: "json",
      success: (response) => {
        if (response.success) {
          // Update the UI
          const subjectItem = $(this).parent();
          subjectItem.html(`
              <input type="text" class="form-control w-full p-2 border rounded" 
                     name="subject-${response.outcomeID}" 
                     value="${content}">
              <button type="button" class="update-subject-btn ml-2 bg-blue-500 text-white p-2 rounded" 
                      data-outcome-id="${response.outcomeID}">
                  <i class="fas fa-save"></i>
              </button>
              <button type="button" class="delete-subject-btn ml-2 bg-red-500 text-white p-2 rounded" 
                      data-outcome-id="${response.outcomeID}">
                  <i class="fas fa-trash"></i>
              </button>
            `);

          alert(response.message);
        } else {
          alert("Error: " + response.message);
        }
      },
      error: () => {
        alert("An error occurred while saving the subject");
      },
    });
  });

  // Update existing subject
  $(document).on("click", ".update-subject-btn", function () {
    const outcomeId = $(this).data("outcome-id");
    const inputField = $(this).parent().find("input");
    const content = inputField.val().trim();

    if (!content) {
      alert("Please enter a subject name");
      return;
    }

    // Send AJAX request to update the subject
    const formData = new FormData();
    formData.append("type", "subject");
    formData.append("isNew", "false");
    formData.append("subpage", "31"); // SHS subpage
    formData.append("outcomeID", outcomeId);
    formData.append("content", content);

    $.ajax({
      url: "../page-functions/addStrandItem.php",
      type: "POST",
      data: formData,
      contentType: false,
      processData: false,
      dataType: "json",
      success: (response) => {
        if (response.success) {
          alert(response.message);
        } else {
          alert("Error: " + response.message);
        }
      },
      error: () => {
        alert("An error occurred while updating the subject");
      },
    });
  });

  // Delete subject
  $(document).on("click", ".delete-subject-btn", function () {
    const outcomeId = $(this).data("outcome-id");

    if (confirm("Are you sure you want to delete this subject?")) {
      // Send AJAX request to delete the subject
      const formData = new FormData();
      formData.append("outcomeID", outcomeId);

      $.ajax({
        url: "../page-functions/deleteStrandOutcome.php",
        type: "POST",
        data: formData,
        contentType: false,
        processData: false,
        dataType: "json",
        success: (response) => {
          if (response.success) {
            // Remove the subject item from the UI
            $(this).parent().remove();
            alert(response.message);
          } else {
            alert("Error: " + response.message);
          }
        },
        error: () => {
          alert("An error occurred while deleting the subject");
        },
      });
    }
  });

  // Remove new subject (not yet saved)
  $(document).on("click", ".remove-subject-btn", function () {
    if (confirm("Are you sure you want to remove this subject?")) {
      $(this).parent().remove();
    }
  });

  // Add new strand
  $("#add-strand-btn").on("click", () => {
    $("#new-strand-form").toggleClass("hidden");
  });

  // Save new strand
  $("#save-new-strand-btn").on("click", () => {
    const strandName = $("#new-strand-name").val().trim();
    const strandDesc = $("#new-strand-desc").val().trim();
    const strandEndDesc = $("#new-strand-end-desc").val().trim();

    if (!strandName) {
      alert("Please enter a strand name");
      return;
    }

    // Send AJAX request to save the new strand
    const formData = new FormData();
    formData.append("isNew", "true");
    formData.append("subpage", "31"); // SHS subpage
    formData.append("strandName", strandName);
    formData.append("strandDesc", strandDesc);
    formData.append("strandEndDesc", strandEndDesc);

    $.ajax({
      url: "../page-functions/addStrandItem.php",
      type: "POST",
      data: formData,
      contentType: false,
      processData: false,
      dataType: "json",
      success: (response) => {
        if (response.success) {
          alert(response.message);
          // Reload the page to show the new strand
          var currentPage = $(".dynamic-load.active").data("file");
          if (currentPage) {
            loadPage(currentPage);
          } else {
            location.reload();
          }
        } else {
          alert("Error: " + response.message);
        }
      },
      error: () => {
        alert("An error occurred while saving the strand");
      },
    });
  });

  // Update existing strand
  $(document).on("click", ".update-strand-btn", function () {
    const strandId = $(this).data("strand-id");
    const descId = $(this).data("desc-id");
    const endDescId = $(this).data("end-desc-id");

    const strandName = $("#strand-name-" + strandId)
      .val()
      .trim();
    const strandDesc = $("#strand-desc-" + descId)
      .val()
      .trim();
    const strandEndDesc = $("#strand-end-desc-" + endDescId)
      .val()
      .trim();

    if (!strandName) {
      alert("Please enter a strand name");
      return;
    }

    // Send AJAX request to update the strand
    const formData = new FormData();
    formData.append("isNew", "false");
    formData.append("subpage", "31"); // SHS subpage
    formData.append("strandID", strandId);
    formData.append("descID", descId);
    formData.append("endDescID", endDescId);
    formData.append("strandName", strandName);
    formData.append("strandDesc", strandDesc);
    formData.append("strandEndDesc", strandEndDesc);

    $.ajax({
      url: "../page-functions/addStrandItem.php",
      type: "POST",
      data: formData,
      contentType: false,
      processData: false,
      dataType: "json",
      success: (response) => {
        if (response.success) {
          alert(response.message);
        } else {
          alert("Error: " + response.message);
        }
      },
      error: () => {
        alert("An error occurred while updating the strand");
      },
    });
  });

  // Delete strand
  $(document).on("click", ".delete-strand-btn", function () {
    const strandId = $(this).data("strand-id");
    const strandName = $("#strand-name-" + strandId).val();

    if (
      confirm(
        `Are you sure you want to delete the strand "${strandName}" and all its subjects?`
      )
    ) {
      // Send AJAX request to delete the strand
      const formData = new FormData();
      formData.append("strandID", strandId);

      $.ajax({
        url: "../page-functions/deleteStrand.php",
        type: "POST",
        data: formData,
        contentType: false,
        processData: false,
        dataType: "json",
        success: (response) => {
          if (response.success) {
            alert(response.message);
            // Remove the strand from the UI
            $("#strand-container-" + strandId).remove();
          } else {
            alert("Error: " + response.message);
          }
        },
        error: () => {
          alert("An error occurred while deleting the strand");
        },
      });
    }
  });
}
