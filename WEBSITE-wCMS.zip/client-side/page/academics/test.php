// Create test-include.php with just:
<?php echo "TEST INCLUDE WORKING"; 

include_once "../../__includes/message-bubble.php";


?>