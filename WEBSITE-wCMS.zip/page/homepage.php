<?php
    require_once '../__includes/head.php';
?>

<body>
    <?php require_once '../__includes/navbar.php'; ?>
    <div class="homepage-body">
        <?php require_once '../page-views/homepage-views.php'; ?>
    </div>
    <?php
    require_once '../__includes/footer.php';
    ?>
</body>