<?php
session_start();
require_once "../../classes/pages.class.php";

$accManagementObj = new Pages;

// Fetch content managers
$contentManage = $accManagementObj->fetchContentManagers();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Content Manager Accounts</title>
    <style>
        /* File input styling */
        .custom-file-input {
            position: relative;
            display: inline-block;
            width: 100%;
        }
        
        .custom-file-input input[type="file"] {
            position: absolute;
            top: 0;
            left: 0;
            opacity: 0;
            width: 100%;
            height: 100%;
            cursor: pointer;
            z-index: 10;
        }
        
        .custom-file-label {
            display: flex;
            align-items: center;
            justify-content: space-between;
            padding: 0.5rem 1rem;
            background-color: #f3f4f6;
            border: 1px solid #d1d5db;
            border-radius: 0.375rem;
            color: #4b5563;
            transition: all 0.2s ease;
        }
        
        .custom-file-input:hover .custom-file-label {
            border-color: #9ca3af;
        }
        
        /* Card hover effect */
        .college-card {
            transition: all 0.3s ease;
        }
        
        .college-card:hover {
            transform: translateY(-5px);
            box-shadow: 0 10px 25px -5px rgba(189, 15, 3, 0.1), 0 8px 10px -6px rgba(189, 15, 3, 0.1);
        }
    </style>
    <!-- DataTables CSS -->
<link rel="stylesheet" type="text/css" href="https://cdn.datatables.net/1.11.5/css/jquery.dataTables.min.css">
<link rel="stylesheet" type="text/css" href="https://cdn.datatables.net/responsive/2.2.9/css/responsive.dataTables.min.css">
</head>
<body class="bg-gray-50">
    <div class="container mx-auto py-10 px-4">
        <h1 class="text-3xl font-bold text-center mb-10">Academic Management</h1>
        
        <?php if(isset($_SESSION['success_msg'])): ?>
            <div class="bg-green-100 border-l-4 border-green-500 text-green-700 p-4 mb-6 rounded" role="alert">
                <div class="flex">
                    <svg xmlns="http://www.w3.org/2000/svg" class="h-6 w-6 mr-2" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M5 13l4 4L19 7" />
                    </svg>
                    <span><?php echo $_SESSION['success_msg']; ?></span>
                </div>
            </div>
            <?php unset($_SESSION['success_msg']); ?>
        <?php endif; ?>
        
        <?php if(isset($_SESSION['error_msg'])): ?>
            <div class="bg-red-100 border-l-4 border-red-500 text-red-700 p-4 mb-6 rounded" role="alert">
                <div class="flex">
                    <svg xmlns="http://www.w3.org/2000/svg" class="h-6 w-6 mr-2" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 8v4m0 4h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z" />
                    </svg>
                    <span><?php echo $_SESSION['error_msg']; ?></span>
                </div>
            </div>
            <?php unset($_SESSION['error_msg']); ?>
        <?php endif; ?>
        
        <!-- Add College Department Section -->
<div class="mb-12 bg-white rounded-lg shadow-md overflow-hidden">
    <div class="bg-primary text-white p-4">
        <h2 class="text-xl font-semibold">Add New College Department</h2>
    </div>
    <div class="p-6">
        <form id="addCollegeForm" method="POST" enctype="multipart/form-data" class="space-y-6">
            <div class="grid grid-cols-1 md:grid-cols-2 gap-6">
                <!-- Department Information -->
                <div class="space-y-4">
                    <div>
                        <label for="collegeName" class="block text-sm font-medium text-gray-700 mb-1">Department Name</label>
                        <input type="text" id="collegeName" name="collegeName" class="w-full px-4 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-primary focus:border-transparent" placeholder="Enter department name (e.g. College of Computing Studies)" required>
                        <p class="mt-1 text-xs text-gray-500">An account will be created with email: <span id="emailPreview" class="font-medium">departmentname@wmsu.edu.ph</span></p>
                    </div>
                    
                    <div>
                        <label for="defaultPassword" class="block text-sm font-medium text-gray-700 mb-1">Default Password</label>
                        <div class="relative">
                            <input type="password" id="defaultPassword" name="defaultPassword" class="w-full px-4 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-primary focus:border-transparent" value="wmsu123" required>
                            <button type="button" id="togglePassword" class="absolute inset-y-0 right-0 pr-3 flex items-center text-gray-600">
                                <svg xmlns="http://www.w3.org/2000/svg" class="h-5 w-5" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M15 12a3 3 0 11-6 0 3 3 0 016 0z" />
                                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M2.458 12C3.732 7.943 7.523 5 12 5c4.478 0 8.268 2.943 9.542 7-1.274 4.057-5.064 7-9.542 7-4.477 0-8.268-2.943-9.542-7z" />
                                </svg>
                            </button>
                        </div>
                        <p class="mt-1 text-xs text-gray-500">The content manager will need to change this on first login</p>
                    </div>
                    
                    <div>
                        <label for="establishedYear" class="block text-sm font-medium text-gray-700 mb-1">Established (Academic Year)</label>
                        <div class="flex items-center space-x-2">
                            <input type="text" id="establishedYear" name="establishedYear" class="w-full px-4 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-primary focus:border-transparent" placeholder="e.g. 1995-1996" pattern="\d{4}-\d{4}" title="Format: YYYY-YYYY (e.g. 1995-1996)">
                            <div class="relative" data-tooltip="Format: YYYY-YYYY">
                                <svg xmlns="http://www.w3.org/2000/svg" class="h-5 w-5 text-gray-400" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M13 16h-1v-4h-1m1-4h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z" />
                                </svg>
                            </div>
                        </div>
                        <p class="mt-1 text-xs text-gray-500">When was this department established? (Format: YYYY-YYYY)</p>
                    </div>
                </div>
                
                <!-- Department Logo Upload -->
                <div class="space-y-4">
                    <div>
                        <label class="block text-sm font-medium text-gray-700 mb-1">Department Logo</label>
                        <div class="border border-dashed border-gray-300 rounded-lg p-4 text-center">
                            <div class="mb-4">
                                <img id="logoPreview" src="../../imgs/default-dept-img.png" alt="Logo Preview" class="mx-auto h-32 w-32 object-contain">
                            </div>
                            
                            <div class="custom-file-input">
                                <input type="file" name="collegeLogo" id="collegeLogo" accept="image/*" onchange="previewLogo(this)">
                                <div class="custom-file-label">
                                    <span id="fileNameDisplay">Choose logo file...</span>
                                    <svg xmlns="http://www.w3.org/2000/svg" class="h-5 w-5 text-gray-400" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M7 16a4 4 0 01-.88-7.903A5 5 0 1115.9 6L16 6a5 5 0 011 9.9M15 13l-3-3m0 0l-3 3m3-3v12" />
                                    </svg>
                                </div>
                            </div>
                            
                            <p class="mt-2 text-xs text-gray-500">Recommended: Square image, 512x512px or larger</p>
                        </div>
                    </div>                            
                </div>
            </div>
            
            <div class="flex justify-end">
                <button type="button" onclick="addCollege()" class="px-6 py-3 bg-primary hover:bg-primaryDark text-white font-medium rounded-md shadow-sm transition-colors focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-primary">
                    <div class="flex items-center">
                        <svg xmlns="http://www.w3.org/2000/svg" class="h-5 w-5 mr-2" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 6v6m0 0v6m0-6h6m-6 0H6" />
                        </svg>
                        Add Department & Create Account
                    </div>
                </button>
            </div>
        </form>
    </div>
</div>
        
        
        <!-- Content Manager Accounts Section -->
<h2 class="text-2xl font-bold text-gray-800 mb-6">Content Manager Accounts</h2>

<div class="bg-white rounded-lg shadow-md overflow-hidden mb-8">
    <?php if(!empty($contentManage)): ?>
        <div class="p-4">
            <table id="accountsTable" class="w-full stripe hover" style="width:100%">
                <thead class="bg-gray-100">
                    <tr>
                        <th class="px-4 py-3 text-left">Profile</th>
                        <th class="px-4 py-3 text-left">Name</th>
                        <th class="px-4 py-3 text-left">Email</th>
                        <th class="px-4 py-3 text-left">Role</th>
                        <th class="px-4 py-3 text-left">Department</th>
                        <th class="px-4 py-3 text-left">Established</th>
                        <th class="px-4 py-3 text-left">Status</th>
                        <th class="px-4 py-3 text-left">Actions</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach($contentManage as $manager): ?>
                        <tr class="border-b hover:bg-gray-50">
                            <td class="px-4 py-3">
                                <div class="w-12 h-12 rounded-full overflow-hidden border-2 border-gray-200">
                                    <?php if(!empty($manager['profileImg'])): ?>
                                        <img src="<?php echo htmlspecialchars($manager['profileImg']); ?>" class="w-full h-full object-cover" alt="Profile Image">
                                    <?php else: ?>
                                        <img src="/WEBSITE-wCMS/imgs/profiles/default-profile.png" class="w-full h-full object-cover" alt="Default Profile">
                                    <?php endif; ?>
                                </div>
                            </td>
                            <td class="px-4 py-3 font-medium">
                                <?php echo htmlspecialchars($manager['firstName'] . ' ' . $manager['lastName']); ?>
                            </td>
                            <td class="px-4 py-3">
                                <?php echo htmlspecialchars($manager['email']); ?>
                            </td>
                            <td class="px-4 py-3">
                                <span class="px-3 py-1 text-xs font-semibold text-white bg-cyan-600 rounded-full">
                                    <?php 
                                    echo isset($manager['roleName']) ? htmlspecialchars($manager['roleName']) : 'Role ID: ' . htmlspecialchars($manager['role_id']); 
                                    ?>
                                </span>
                            </td>
                            <td class="px-4 py-3">
                                <span class="px-3 py-1 text-xs font-semibold text-white bg-green-600 rounded-full">
                                    <?php 
                                    echo isset($manager['pageName']) ? htmlspecialchars($manager['pageName']) : 'Page ID: ' . htmlspecialchars($manager['pageID']); 
                                    ?>
                                </span>
                                <?php if(!empty($manager['subpage_assigned']) || !empty($manager['subPageName'])): ?>
                                    <br>
                                    <span class="px-3 py-1 text-xs font-semibold text-white bg-amber-500 rounded-full mt-1 inline-block">
                                        <?php 
                                        echo isset($manager['subPageName']) ? htmlspecialchars($manager['subPageName']) : htmlspecialchars($manager['subpage_assigned']); 
                                        ?>
                                    </span>
                                <?php endif; ?>
                            </td>
                            <td class="px-4 py-3">
                                <?php if(!empty($manager['established_year'])): ?>
                                    <span class="px-3 py-1 text-xs font-semibold text-white bg-blue-600 rounded-full">
                                        <?php echo htmlspecialchars($manager['established_year']); ?>
                                    </span>
                                <?php else: ?>
                                    <span class="text-gray-400">-</span>
                                <?php endif; ?>
                            </td>
                            <td class="px-4 py-3">
                                <?php if(isset($manager['status']) && $manager['status'] == 0): ?>
                                    <span class="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-red-100 text-red-800">
                                        <svg xmlns="http://www.w3.org/2000/svg" class="h-3 w-3 mr-1" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 8v4m0 4h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z" />
                                        </svg>
                                        Suspended
                                    </span>
                                <?php else: ?>
                                    <span class="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-green-100 text-green-800">
                                        <svg xmlns="http://www.w3.org/2000/svg" class="h-3 w-3 mr-1" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M5 13l4 4L19 7" />
                                        </svg>
                                        Active
                                    </span>
                                <?php endif; ?>
                            </td>
                            <td class="px-4 py-3">
                                <?php if(isset($manager['status']) && $manager['status'] == 0): ?>
                                    <form method="POST" action="../page-functions/update-account-status.php" class="inline status-form">
                                        <input type="hidden" name="manager_id" value="<?php echo $manager['id']; ?>">
                                        <input type="hidden" name="reactivate_account" value="1">
                                        <button type="submit" class="inline-flex items-center px-3 py-1 bg-green-600 text-white text-xs font-medium rounded-md hover:bg-green-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-green-500 transition">
                                            <svg xmlns="http://www.w3.org/2000/svg" class="h-4 w-4 mr-1" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                                                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z" />
                                            </svg>
                                            Reactivate
                                        </button>
                                    </form>
                                <?php else: ?>
                                    <form method="POST" action="../page-functions/update-account-status.php" class="inline status-form">
                                        <input type="hidden" name="manager_id" value="<?php echo $manager['id']; ?>">
                                        <input type="hidden" name="suspend_account" value="1">
                                        <button type="submit" class="inline-flex items-center px-3 py-1 bg-red-600 text-white text-xs font-medium rounded-md hover:bg-red-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-red-500 transition">
                                            <svg xmlns="http://www.w3.org/2000/svg" class="h-4 w-4 mr-1" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                                                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M18.364 18.364A9 9 0 005.636 5.636m12.728 12.728A9 9 0 015.636 5.636m12.728 12.728L5.636 5.636" />
                                            </svg>
                                            Suspend
                                        </button>
                                    </form>
                                <?php endif; ?>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </div>
    <?php else: ?>
        <div class="p-6">
            <div class="bg-blue-100 border-l-4 border-blue-500 text-blue-700 p-4 rounded" role="alert">
                <div class="flex">
                    <svg xmlns="http://www.w3.org/2000/svg" class="h-6 w-6 mr-2" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M13 16h-1v-4h-1m1-4h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z" />
                    </svg>
                    <span>No content manager accounts found.</span>
                </div>
            </div>
        </div>
    <?php endif; ?>
</div>
    </div>

    <script>
        // Preview logo image
        function previewLogo(input) {
            if (input.files && input.files[0]) {
                const fileName = input.files[0].name;
                document.getElementById('fileNameDisplay').textContent = fileName;
                
                const reader = new FileReader();
                reader.onload = function(e) {
                    document.getElementById('logoPreview').src = e.target.result;
                }
                reader.readAsDataURL(input.files[0]);
            }
        }
        
        // Preview banner image
        function previewBanner(input) {
            if (input.files && input.files[0]) {
                const fileName = input.files[0].name;
                document.getElementById('bannerFileNameDisplay').textContent = fileName;
                
                const reader = new FileReader();
                reader.onload = function(e) {
                    document.getElementById('bannerPreview').src = e.target.result;
                }
                reader.readAsDataURL(input.files[0]);
            }
        }
        
        // Validate academic year format
        document.getElementById('establishedYear').addEventListener('input', function() {
            const value = this.value;
            const yearPattern = /^\d{4}-\d{4}$/;
            
            if (value && !yearPattern.test(value)) {
                this.setCustomValidity('Please use format: YYYY-YYYY (e.g. 1995-1996)');
            } else {
                this.setCustomValidity('');
            }
        });
        
        // Add College function (to be implemented by the user)
        // Add College function
function addCollege() {
    // Get form data
    const form = document.getElementById('addCollegeForm');
    const collegeName = document.getElementById('collegeName').value;
    const defaultPassword = document.getElementById('defaultPassword').value;
    const establishedYear = document.getElementById('establishedYear').value;
    
    // Basic validation
    if (!collegeName) {
        alert('Please enter a college department name');
        return;
    }
    
    if (!defaultPassword) {
        alert('Please enter a default password');
        return;
    }
    
    // Validate academic year format if provided
    if (establishedYear) {
        const yearPattern = /^\d{4}-\d{4}$/;
        if (!yearPattern.test(establishedYear)) {
            alert('Academic year must be in format: YYYY-YYYY (e.g. 1995-1996)');
            return;
        }
    }
    
    // Show loading state
    const submitButton = form.querySelector('button[type="button"]');
    const originalButtonText = submitButton.innerHTML;
    submitButton.innerHTML = `
        <svg class="animate-spin -ml-1 mr-2 h-4 w-4 text-white" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24">
            <circle class="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" stroke-width="4"></circle>
            <path class="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path>
        </svg>
        Processing...
    `;
    submitButton.disabled = true;
    
    // Create FormData and append the password
    const formData = new FormData(form);
    formData.append('defaultPassword', defaultPassword);
    
    // Use jQuery AJAX
    $.ajax({
        url: '../page-functions/addCollegeDept.php',
        type: 'POST',
        data: formData,
        processData: false,
        contentType: false,
        success: function(data) {
            // Reset button state
            submitButton.innerHTML = originalButtonText;
            submitButton.disabled = false;
            
            if (data.success) {
                // Show success message
                const successMessage = $(`
                    <div class="bg-green-100 border-l-4 border-green-500 text-green-700 p-4 mb-6 rounded">
                        <div class="flex">
                            <svg xmlns="http://www.w3.org/2000/svg" class="h-6 w-6 mr-2" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M5 13l4 4L19 7" />
                            </svg>
                            <span>${data.message || 'College department added successfully!'}</span>
                        </div>
                    </div>
                `);
                
                // Insert success message before the form
                $(form).before(successMessage);
                
                // Remove success message after 5 seconds
                setTimeout(() => {
                    successMessage.fadeOut(function() {
                        $(this).remove();
                    });
                }, 5000);
                
                // Reset form
                form.reset();
                $('#logoPreview').attr('src', '../../imgs/profiles/default-profile.png');
                $('#fileNameDisplay').text('Choose logo file...');
                $('#emailPreview').text('departmentname@wmsu.edu.ph');
                
                // Reload the page after a short delay to show the new department
                setTimeout(() => {
                    location.reload();
                }, 2000);
            } else {
                // Show error message
                alert(data.message || 'An error occurred while adding the college department.');
                console.error('Errors:', data.errors);
            }
        },
        error: function(xhr, status, error) {
            // Reset button state
            submitButton.innerHTML = originalButtonText;
            submitButton.disabled = false;
            
            console.error('AJAX Error:', status, error);
            alert('An error occurred. Please try again.');
        }
    });
}
// Generate email preview based on department name
document.getElementById('collegeName').addEventListener('input', function() {
    const collegeName = this.value.trim();
    let emailName = '';
    
    // Extract the part after "College of" if it exists
    if (collegeName.toLowerCase().startsWith('college of ')) {
        emailName = collegeName.substring(11).trim();
    } else {
        emailName = collegeName;
    }
    
    // Remove spaces and special characters
    emailName = emailName.toLowerCase().replace(/[^a-z0-9]/g, '');
    
    // Update the email preview
    document.getElementById('emailPreview').textContent = emailName + '@wmsu.edu.ph';
});

// Toggle password visibility
document.getElementById('togglePassword').addEventListener('click', function() {
    const passwordInput = document.getElementById('defaultPassword');
    if (passwordInput.type === 'password') {
        passwordInput.type = 'text';
        this.innerHTML = `
            <svg xmlns="http://www.w3.org/2000/svg" class="h-5 w-5" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M13.875 18.825A10.05 10.05 0 0112 19c-4.478 0-8.268-2.943-9.543-7a9.97 9.97 0 011.563-3.029m5.858.908a3 3 0 114.243 4.243M9.878 9.878l4.242 4.242M9.88 9.88l-3.29-3.29m7.532 7.532l3.29 3.29M3 3l3.59 3.59m0 0A9.953 9.953 0 0112 5c4.478 0 8.268 2.943 9.543 7a10.025 10.025 0 01-4.132 5.411m0 0L21 21" />
            </svg>
        `;
    } else {
        passwordInput.type = 'password';
        this.innerHTML = `
            <svg xmlns="http://www.w3.org/2000/svg" class="h-5 w-5" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M15 12a3 3 0 11-6 0 3 3 0 016 0z" />
                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M2.458 12C3.732 7.943 7.523 5 12 5c4.478 0 8.268 2.943 9.542 7-1.274 4.057-5.064 7-9.542 7-4.477 0-8.268-2.943-9.542-7z" />
            </svg>
        `;
    }
});
    </script>
<!-- DataTables JS -->
<script type="text/javascript" src="https://cdn.datatables.net/1.11.5/js/jquery.dataTables.min.js"></script>
<script type="text/javascript" src="https://cdn.datatables.net/responsive/2.2.9/js/dataTables.responsive.min.js"></script>
<script>
    $(document).ready(function() {
        $('#accountsTable').DataTable({
            responsive: true,
            columnDefs: [
                { responsivePriority: 1, targets: 0 },
                { responsivePriority: 2, targets: 1 },
                { responsivePriority: 3, targets: 7 }
            ],
            language: {
                search: "Search accounts:",
                lengthMenu: "Show _MENU_ accounts per page",
                info: "Showing _START_ to _END_ of _TOTAL_ accounts",
                emptyTable: "No content manager accounts found"
            }
        });
    });
</script>
<!-- Add this JavaScript at the end of the file, just before the closing </body> tag -->
<script>
    // Handle form submissions via AJAX to prevent page reload
    $(document).ready(function() {
        $('.status-form').on('submit', function(e) {
            e.preventDefault();
            
            const form = $(this);
            const managerId = form.find('input[name="manager_id"]').val();
            const row = form.closest('tr');
            
            $.ajax({
                url: '../page-functions/update-account-status.php',
                type: 'POST',
                data: form.serialize(),
                dataType: 'json',
                success: function(response) {
                    if (response.success) {
                        // Show success message
                        const successMessage = $(`
                            <div class="bg-green-100 border-l-4 border-green-500 text-green-700 p-4 mb-6 rounded fixed top-4 right-4 z-50 shadow-lg">
                                <div class="flex">
                                    <svg xmlns="http://www.w3.org/2000/svg" class="h-6 w-6 mr-2" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M5 13l4 4L19 7" />
                                    </svg>
                                    <span>${response.message}</span>
                                </div>
                            </div>
                        `);
                        
                        $('body').append(successMessage);
                        
                        // Remove success message after 3 seconds
                        setTimeout(() => {
                            successMessage.fadeOut(function() {
                                $(this).remove();
                            });
                        }, 3000);
                        
                        // Refresh the table row to show updated status
                        location.reload();
                    } else {
                        // Show error message
                        alert(response.message || 'An error occurred while updating the account status.');
                    }
                },
                error: function(xhr, status, error) {
                    console.error('AJAX Error:', status, error);
                    alert('An error occurred. Please try again.');
                }
            });
        });
    });
</script>
</body>
</html>
