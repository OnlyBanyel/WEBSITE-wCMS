<?php
require_once __DIR__ . "/db_connection.class.php";

class ElementStyler {
    protected $db;
    
    public function __construct() {
        $this->db = new Database;
    }
    
    /**
     * Get all available style options from the styles table
     * 
     * @return array Associative array of style options grouped by type
     */
    public function getStyleOptions() {
        $sql = "SELECT * FROM styles ORDER BY type, className";
        $stmt = $this->db->connect()->prepare($sql);
        
        if ($stmt->execute()) {
            $results = $stmt->fetchAll(PDO::FETCH_ASSOC);
            $options = [];
            
            foreach ($results as $row) {
                $options[$row['type']][] = $row;
            }
            
            return $options;
        }
        
        return [];
    }
    
    /**
     * Get element styles as a JSON string
     * 
     * @param int $sectionID The section ID
     * @return string|null JSON string of styles or null if not found
     */
    public function getElementStyles($sectionID) {
        $sql = "SELECT styles FROM page_sections WHERE sectionID = :sectionID";
        $stmt = $this->db->connect()->prepare($sql);
        $stmt->bindParam(':sectionID', $sectionID, PDO::PARAM_INT);
        
        if ($stmt->execute()) {
            $result = $stmt->fetch(PDO::FETCH_ASSOC);
            return $result ? $result['styles'] : null;
        }
        
        return null;
    }
    
    /**
     * Get element styles as an associative array
     * 
     * @param int $sectionID The section ID
     * @return array Associative array of styles
     */
    public function getElementStylesArray($sectionID) {
        $styles = $this->getElementStyles($sectionID);
        return $styles ? json_decode($styles, true) : [];
    }
    
    /**
     * Get element styles as a space-separated class string
     * 
     * @param int $sectionID The section ID
     * @return string Space-separated class string
     */
    public function getElementClassString($sectionID) {
        $styles = $this->getElementStylesArray($sectionID);
        return implode(' ', $styles);
    }
    
    /**
     * Save element style
     * 
     * @param int $sectionID The section ID
     * @param string $category Style category
     * @param string $value Style value
     * @return bool True if successful, false otherwise
     */
    public function saveElementStyle($sectionID, $category, $value) {
        // Get current styles
        $styles = $this->getElementStylesArray($sectionID);
        
        // Update or add the style
        if (empty($value)) {
            // Remove the style if value is empty
            if (isset($styles[$category])) {
                unset($styles[$category]);
            }
        } else {
            $styles[$category] = $value;
        }
        
        // Save the updated styles
        $stylesJson = json_encode($styles);
        
        $sql = "UPDATE page_sections SET styles = :styles WHERE sectionID = :sectionID";
        $stmt = $this->db->connect()->prepare($sql);
        $stmt->bindParam(':styles', $stylesJson);
        $stmt->bindParam(':sectionID', $sectionID, PDO::PARAM_INT);
        
        return $stmt->execute();
    }
    
    /**
     * Remove all styles for an element
     * 
     * @param int $sectionID The section ID
     * @return bool True if successful, false otherwise
     */
    public function removeAllElementStyles($sectionID) {
        $sql = "UPDATE page_sections SET styles = NULL WHERE sectionID = :sectionID";
        $stmt = $this->db->connect()->prepare($sql);
        $stmt->bindParam(':sectionID', $sectionID, PDO::PARAM_INT);
        
        return $stmt->execute();
    }
}
?>
