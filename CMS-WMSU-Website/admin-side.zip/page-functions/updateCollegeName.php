<?php
session_start();
require_once '../classes/login.class.php';
require_once '../classes/pages.class.php';

// Initialize classes
$loginObj = new Login();
$pagesObj = new Pages();

// Set content type to JSON
header('Content-Type: application/json');

// Check if user is logged in
if (!isset($_SESSION['account'])) {
    echo json_encode(['success' => false, 'message' => 'User not logged in']);
    exit;
}

// Get subpage from session
$subpage = $_SESSION['account']['subpage_assigned'];

// Log incoming data for debugging
error_log('updateCollegeName.php - POST data: ' . print_r($_POST, true));

// Check if college name is provided
if (isset($_POST['collegeName'])) {
    $value = trim($_POST['collegeName']);
    $textID = isset($_POST['textID']) ? $_POST['textID'] : null;
    $isNew = isset($_POST['isNew']) && $_POST['isNew'] === '1';
    
    // Log the values for debugging
    error_log("College Name: $value");
    error_log("Text ID: $textID");
    error_log("Is New: " . ($isNew ? 'Yes' : 'No'));
    
    // Validate input
    if (empty($value)) {
        echo json_encode(['success' => false, 'message' => 'College name cannot be empty']);
        exit;
    }
    
    try {
        $result = false;
        
        if ($isNew || strpos($textID, 'temp_') === 0) {
            // Add new college name
            error_log("Adding new college name: $value");
            $result = $pagesObj->addContent(
                $subpage,
                'College Profile',
                'text',
                $value,
                null,
                'carousel-logo-text'
            );
            
            if ($result) {
                // Refresh session data
                $_SESSION['collegeData'] = $loginObj->fetchCollegeData($subpage);
                echo json_encode(["success" => true, "message" => "College name added successfully", "isNew" => true]);
            } else {
                error_log("Failed to add college name");
                echo json_encode(["success" => false, "message" => "Failed to add college name"]);
            }
        } else {
            // Update existing college name
            error_log("Updating existing college name: $value, ID: $textID");
            $result = $pagesObj->changeContent($textID, $subpage, $value);
            
            if ($result) {
                // Refresh session data
                $_SESSION['collegeData'] = $loginObj->fetchCollegeData($subpage);
                echo json_encode(["success" => true, "message" => "College name updated successfully", "isNew" => false]);
            } else {
                error_log("Failed to update college name");
                echo json_encode(["success" => false, "message" => "Failed to update college name"]);
            }
        }
    } catch (Exception $e) {
        error_log("Exception: " . $e->getMessage());
        echo json_encode(["success" => false, "message" => "Error: " . $e->getMessage()]);
    }
} else {
    error_log("No college name provided in POST data");
    echo json_encode(["success" => false, "message" => "No college name provided"]);
}
?>
