<?php
session_start();
require_once '../classes/login.class.php';
require_once '../classes/pages.class.php';

$loginObj = new Login;
$pagesObj = new Pages;

// Check if we're adding a new department
if (isset($_POST['addNewDepartment'])) {
    $subpage = $_SESSION['account']['subpage_assigned'];
    
    // Add a new department with default values
    $newDeptContent = "New Department";
    $newDeptID = $pagesObj->addContent(
        $subpage,
        'Departments',
        'text',
        $newDeptContent,
        null,
        'department-item'
    );
    
    if ($newDeptID) {
        // Refresh session data
        $_SESSION['collegeData'] = $loginObj->fetchCollegeData($subpage);
        
        // Redirect back to departments page
        header("Location: ../page-views/departments.php");
        exit;
    } else {
        echo json_encode(["success" => false, "message" => "Failed to add new department."]);
        exit;
    }
}

echo json_encode(["success" => false, "message" => "Invalid request."]);
?>
