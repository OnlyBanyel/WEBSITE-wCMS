<link rel="stylesheet" href="../vendors/mdi/css/materialdesignicons.min.css">
<link rel="stylesheet" href="../vendors/css/vendor.bundle.base.css">
<link rel="stylesheet" href="../vendors/coreui-5.3.1-dist/css/coreui.min.css">
<link rel="stylesheet" href="../vendors/datatable/datatables.min.css">
<link rel="stylesheet" href="../vendors/bootstrap/bootstrap.min.css">
<link rel="stylesheet" href="../css/tailwind.css">

<script src="../vendors/jquery-3.7.1/jquery-3.7.1.min.js"></script>
<script src="../vendors/coreui-5.3.1-dist/js/coreui.bundle.min.js"></script>
<script src="../vendors/datatable/datatables.min.js"></script>
<script src="../vendors/bootstrap/bootstrap.min.js"></script>
